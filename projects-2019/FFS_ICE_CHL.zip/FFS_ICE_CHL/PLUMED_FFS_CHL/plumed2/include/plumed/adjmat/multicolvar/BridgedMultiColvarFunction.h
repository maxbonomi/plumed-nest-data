#include "../../multicolvar/BridgedMultiColvarFunction.h"
